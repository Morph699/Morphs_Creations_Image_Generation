@echo off
chcp 65001 >nul
mode con:cols=78 lines=26
color 0A
setlocal EnableExtensions EnableDelayedExpansion

:: Setup Core Working Directories
set "T_Dir=%~dp0ToolboxData"
set "Out_Dir=%T_Dir%\GeneratedImages"
set "PS_Engine=%T_Dir%\AIGenEngine.ps1"

if not exist "%T_Dir%" mkdir "%T_Dir%"
if not exist "%Out_Dir%" mkdir "%Out_Dir%"

:: Step 0: Deploy/Update PowerShell Sub-Engine File
(
echo $ErrorActionPreference = 'Stop'
echo $rawPrompt = $env:RAW_PROMPT_VAL
echo $viewerPath = $env:VIEWER_PATH
echo $outDir = $env:OUT_DIR
echo.
echo Write-Host "============================================================================" -ForegroundColor Green
echo Write-Host "                    AI IMAGE GENERATION ENGINE (PS CORE)                    " -ForegroundColor Green
echo Write-Host "============================================================================" -ForegroundColor Green
echo Write-Host ""
echo.
echo # Dependency Check
echo if (-not (Test-Path $viewerPath^)^) {
echo     Write-Host "[*] Native Image Viewer missing. Downloading dependency..." -ForegroundColor Yellow
echo     try {
echo         $wc = New-Object System.Net.WebClient
echo         $wc.Headers.Add("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0.0.0 Safari/537.36"^)
echo         $wc.DownloadFile("https://github.com/deminimis/minimalimageviewer/releases/download/v2.0.3/MinimalImageViewer.exe", $viewerPath^)
echo         Write-Host "[OK] Viewer downloaded successfully." -ForegroundColor Green
echo     } catch {
echo         Write-Host "[ERROR] Failed to download MinimalImageViewer.exe:" $_.Exception.Message -ForegroundColor Red
echo         Write-Host ""
echo         Read-Host "Press Enter to return to menu..."
echo         exit 1
echo     }
echo }
echo.
echo # Encode Prompt Parameters
echo Write-Host "[*] Encoding prompt parameters safely..." -ForegroundColor Cyan
echo $encodedPrompt = [System.Uri]::EscapeDataString($rawPrompt^)
echo $seed = Get-Random -Minimum 100000 -Maximum 99999999
echo $targetFile = Join-Path $outDir "AI_Gen_$seed.jpg"
echo $apiUrl = "https://image.pollinations.ai/prompt/$encodedPrompt?width=1024&height=1024&seed=$seed&nologo=true"
echo.
echo Write-Host "[*] Request URL: $apiUrl" -ForegroundColor Gray
echo Write-Host "[*] Processing Request (Seed: $seed, Timeout: 60s)..." -ForegroundColor Yellow
echo.
echo try {
echo     [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
echo     $req = [System.Net.HttpWebRequest]::Create($apiUrl^)
echo     $req.UserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0.0.0 Safari/537.36"
echo     $req.Timeout = 60000
echo     $res = $req.GetResponse(^)
echo     $stream = $res.GetResponseStream(^)
echo     $fileStream = [System.IO.File]::Create($targetFile^)
echo     $stream.CopyTo($fileStream^)
echo     $fileStream.Close(^)
echo     $stream.Close(^)
echo     $res.Close(^)
echo } catch {
echo     Write-Host ""
echo     Write-Host "[ERROR] Request failed:" $_.Exception.Message -ForegroundColor Red
echo     Write-Host ""
echo     Read-Host "Press Enter to return to menu..."
echo     exit 1
echo }
echo.
echo # Validate Download Size
echo if (-not (Test-Path $targetFile^)^) {
echo     Write-Host "[ERROR] Target file was not created on disk." -ForegroundColor Red
echo     Read-Host "Press Enter to return to menu..."
echo     exit 1
echo }
echo.
echo $fileSize = (Get-Item $targetFile^).Length
echo if ($fileSize -lt 10240^) {
echo     Write-Host ""
echo     Write-Host "============================================================================" -ForegroundColor Red
echo     Write-Host "[ERROR] API returned error response instead of image ($fileSize bytes)." -ForegroundColor Red
echo     Write-Host "==================== DIAGNOSTIC PAYLOAD CONTENTS ====================" -ForegroundColor Yellow
echo     Get-Content $targetFile
echo     Write-Host "============================================================================" -ForegroundColor Yellow
echo     Remove-Item $targetFile -Force -ErrorAction SilentlyContinue
echo     Write-Host ""
echo     Read-Host "Press Enter to return to menu..."
echo     exit 1
echo }
echo.
echo Write-Host ""
echo Write-Host "[SUCCESS] Image generated and validated ($fileSize bytes)." -ForegroundColor Green
echo Write-Host "[*] Launching Native Image Viewer..." -ForegroundColor Cyan
echo Start-Process $viewerPath -ArgumentList "`"$targetFile`""
echo Write-Host ""
echo Read-Host "Press Enter to return to menu..."
) > "%PS_Engine%"

:: Startup Animated Multi-Color Header Rendering
cls
powershell -ExecutionPolicy Bypass -Command "$colors=@('Cyan','Green','Magenta','Yellow','White','DarkCyan'); $logo=@('        ßßß    ßßß   ßßßßßß   ßßßßßß   ßßßßßß   ßß   ßß  ßßßßßßß','        ßßßß  ßßßß  ßß    ßß  ßß   ßß  ßß   ßß  ßß   ßß  ßß     ','        ßß ßßßß ßß  ßß    ßß  ßßßßßß   ßßßßßß   ßßßßßßß  ßßßßßßß','        ßß  ßß  ßß  ßß    ßß  ßß   ßß  ßß       ßß   ßß       ßß','        ßß      ßß   ßßßßßß   ßß   ßß  ßß       ßß   ßß  ßßßßßßß',' ','   ßßßßßß  ßßßßßß  ßßßßßßß   ßßßßß  ßßßßßßßß  ßß  ßßßßßß  ßßß    ßß  ßßßßßßß','  ßß       ßß   ßß ßß       ßß   ßß    ßß     ßß ßß    ßß ßßßß   ßß  ßß     ','  ßß       ßßßßßß  ßßßßßßß  ßßßßßßß    ßß     ßß ßß    ßß ßß ßß  ßß  ßßßßßßß','  ßß       ßß   ßß ßß       ßß   ßß    ßß     ßß ßß    ßß ßß  ßß ßß       ßß','   ßßßßßß  ßß   ßß ßßßßßßß  ßß   ßß    ßß     ßß  ßßßßßß  ßß   ßßßß  ßßßßßßß'); foreach ($line in $logo) { if ($line.Trim().Length -eq 0) { Write-Host ''; continue }; [char[]]$chars = $line.ToCharArray(); foreach ($c in $chars) { if ($c -eq 'ß') { $color = Get-Random -InputObject $colors; Write-Host $c -ForegroundColor $color -NoNewline } else { Write-Host $c -NoNewline } }; Write-Host '' }"
echo.
timeout /t 2 >nul

:AI_Image_Menu
cls
echo ßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßß
echo.
echo         ßßß    ßßß   ßßßßßß   ßßßßßß   ßßßßßß   ßß   ßß  ßßßßßßß
echo         ßßßß  ßßßß  ßß    ßß  ßß   ßß  ßß   ßß  ßß   ßß  ßß     
echo         ßß ßßßß ßß  ßß    ßß  ßßßßßß   ßßßßßß   ßßßßßßß  ßßßßßßß
echo         ßß  ßß  ßß  ßß    ßß  ßß   ßß  ßß       ßß   ßß       ßß
echo         ßß      ßß   ßßßßßß   ßß   ßß  ßß       ßß   ßß  ßßßßßßß
echo.
echo  ßßßßßß  ßßßßßß  ßßßßßßß   ßßßßß  ßßßßßßßß  ßß  ßßßßßß  ßßß    ßß  ßßßßßßß
echo ßß       ßß   ßß ßß       ßß   ßß    ßß     ßß ßß    ßß ßßßß   ßß  ßß     
echo ßß       ßßßßßß  ßßßßßßß  ßßßßßßß    ßß     ßß ßß    ßß ßß ßß  ßß  ßßßßßßß
echo ßß       ßß   ßß ßß       ßß   ßß    ßß     ßß ßß    ßß ßß  ßß ßß       ßß
echo  ßßßßßß  ßß   ßß ßßßßßßß  ßß   ßß    ßß     ßß  ßßßßßß  ßß   ßßßß  ßßßßßßß
echo.
echo ßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßß
echo ============================================================================
echo                 MORPHS CREATIONS AI IMAGE GENERATOR MODULE                  
echo ============================================================================
echo.
echo [1] Generate New AI Image
echo [2] Open Output Directory
echo [3] Return to Main Menu
echo.
echo ============================================================================
set /p "user_choice=Select an option [1-3]: "

if "%user_choice%"=="1" goto :Generate_Image_Routine
if "%user_choice%"=="2" (
    start "" "%Out_Dir%"
    goto :AI_Image_Menu
)
if "%user_choice%"=="3" exit /b 0

echo.
echo [!] Invalid selection. Please choose a valid option.
timeout /t 2 >nul
goto :AI_Image_Menu

:Generate_Image_Routine
cls
echo ßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßß
echo.
echo         ßßß    ßßß   ßßßßßß   ßßßßßß   ßßßßßß   ßß   ßß  ßßßßßßß
echo         ßßßß  ßßßß  ßß    ßß  ßß   ßß  ßß   ßß  ßß   ßß  ßß     
echo         ßß ßßßß ßß  ßß    ßß  ßßßßßß   ßßßßßß   ßßßßßßß  ßßßßßßß
echo         ßß  ßß  ßß  ßß    ßß  ßß   ßß  ßß       ßß   ßß       ßß
echo         ßß      ßß   ßßßßßß   ßß   ßß  ßß       ßß   ßß  ßßßßßßß
echo.
echo  ßßßßßß  ßßßßßß  ßßßßßßß   ßßßßß  ßßßßßßßß  ßß  ßßßßßß  ßßß    ßß  ßßßßßßß
echo ßß       ßß   ßß ßß       ßß   ßß    ßß     ßß ßß    ßß ßßßß   ßß  ßß     
echo ßß       ßßßßßß  ßßßßßßß  ßßßßßßß    ßß     ßß ßß    ßß ßß ßß  ßß  ßßßßßßß
echo ßß       ßß   ßß ßß       ßß   ßß    ßß     ßß ßß    ßß ßß  ßß ßß       ßß
echo  ßßßßßß  ßß   ßß ßßßßßßß  ßß   ßß    ßß     ßß  ßßßßßß  ßß   ßßßß  ßßßßßßß
echo.
echo ßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßß
echo ============================================================================
echo                     AI IMAGE GENERATION SUBROUTINE                         
echo ============================================================================
echo.

set "raw_prompt="
set /p "raw_prompt=Enter prompt describing the image to generate: "

if not defined raw_prompt (
    echo.
    echo [!] Empty prompt detected.
    echo Press any key to return to menu...
    pause >nul
    goto :AI_Image_Menu
)

:: Environment Variable Handoff to PowerShell Core Engine
set "RAW_PROMPT_VAL=%raw_prompt%"
set "VIEWER_PATH=%T_Dir%\NativeImageViewer.exe"
set "OUT_DIR=%Out_Dir%"

echo.
echo [*] Invoking PowerShell Core Generation Engine...
powershell -NoProfile -ExecutionPolicy Bypass -File "%PS_Engine%"

goto :AI_Image_Menu