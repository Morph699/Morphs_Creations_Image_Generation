@echo off
chcp 65001 >nul
mode con:cols=78 lines=26
color 0A
setlocal EnableExtensions EnableDelayedExpansion

:: Standalone Module Parameters
set "TOOLBOX_VER=v0.28"
set "MODULE_NAME=Morphs_Creations_Image_Generation"
set "T_Dir=%~dp0ToolboxData"
set "Out_Dir=%T_Dir%\GeneratedImages"
set "PS_Engine=%T_Dir%\AIGenEngine.ps1"

:: Default Model Configuration
set "SELECTED_MODEL=nanobanana"
set "MODEL_DISPLAY=Nano Banana (Google Gemini Flash)"

:: Default Aspect Ratio & Resolution Configuration
set "SELECTED_AR=16:9"
set "SELECTED_TIER=1080p"
set "IMG_WIDTH=1920"
set "IMG_HEIGHT=1080"

if not exist "%T_Dir%" mkdir "%T_Dir%"
if not exist "%Out_Dir%" mkdir "%Out_Dir%"

:: Step 0: Deploy Fresh Sub-Engine File to Disk
call :Ensure_Engine_Script

:: Startup Animated Multi-Color Header Rendering
cls
powershell -ExecutionPolicy Bypass -Command "$colors=@('Cyan','Green','Magenta','Yellow','White','DarkCyan'); $logo=@('        ßßß    ßßß   ßßßßßß   ßßßßßß   ßßßßßß   ßß   ßß  ßßßßßßß','        ßßßß  ßßßß  ßß    ßß  ßß   ßß  ßß   ßß  ßß   ßß  ßß     ','        ßß ßßßß ßß  ßß    ßß  ßßßßßß   ßßßßßß   ßßßßßßß  ßßßßßßß','        ßß  ßß  ßß  ßß    ßß  ßß   ßß  ßß       ßß   ßß       ßß','        ßß      ßß   ßßßßßß   ßß   ßß  ßß       ßß   ßß  ßßßßßßß',' ','   ßßßßßß  ßßßßßß  ßßßßßßß   ßßßßß  ßßßßßßßß  ßß  ßßßßßß  ßßß    ßß  ßßßßßßß','  ßß       ßß   ßß ßß       ßß   ßß    ßß     ßß ßß    ßß ßßßß   ßß  ßß     ','  ßß       ßßßßßß  ßßßßßßß  ßßßßßßß    ßß     ßß ßß    ßß ßß ßß  ßß  ßßßßßßß','  ßß       ßß   ßß ßß       ßß   ßß    ßß     ßß ßß    ßß ßß  ßß ßß       ßß','   ßßßßßß  ßß   ßß ßßßßßßß  ßß   ßß    ßß     ßß  ßßßßßß  ßß   ßßßß  ßßßßßßß'); foreach ($line in $logo) { if ($line.Trim().Length -eq 0) { Write-Host ''; continue }; [char[]]$chars = $line.ToCharArray(); foreach ($c in $chars) { if ($c -eq 'ß') { $color = Get-Random -InputObject $colors; Write-Host $c -ForegroundColor $color -NoNewline } else { Write-Host $c -NoNewline } }; Write-Host '' }"
echo.
timeout /t 2 >nul

:AI_Image_Menu
call :Recalculate_Dimensions
cls
echo ßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßß
echo.
echo         ßßß    ßßß   ßßßßßß   ßßßßßß   ßßßßßß   ßß   ßß  ßßßßßßß
echo         ßßßß  ßßßß  ßß    ßß  ßß   ßß  ßß   ßß  ßß   ßß  ßß     
echo         ßß ßßßß ßß  ßß    ßß  ßßßßßß   ßßßßßß   ßßßßßßß  ßßßßßßß
echo         ßß  ßß  ßß  ßß    ßß  ßß   ßß  ßß       ßß   ßß       ßß
echo         ßß      ßß   ßßßßßß   ßß   ßß  ßß       ßß   ßß  ßßßßßßß
echo.
echo  ßßßßßß  ßßßßßß  ßßßßßßß   ßßßßß  ßßßßßßßß  ßß  ßßßßßß  ßßß    ßß  ßßßßßßß
echo ßß       ßß   ßß ßß       ßß   ßß    ßß     ßß ßß    ßß ßßßß   ßß  ßß     
echo ßß       ßßßßßß  ßßßßßßß  ßßßßßßß    ßß     ßß ßß    ßß ßß ßß  ßß  ßßßßßßß
echo ßß       ßß   ßß ßß       ßß   ßß    ßß     ßß ßß    ßß ßß  ßß ßß       ßß
echo  ßßßßßß  ßß   ßß ßßßßßßß  ßß   ßß    ßß     ßß  ßßßßßß  ßß   ßßßß  ßßßßßßß
echo.
echo ßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßß
echo ============================================================================
echo         %MODULE_NAME% [%TOOLBOX_VER%]      
echo ============================================================================
echo.
echo [1] Generate New AI Image
echo [2] AI Model Engine    (Active: %MODEL_DISPLAY%)
echo [3] Aspect Ratio       (Active: %SELECTED_AR%)
echo [4] Resolution Quality (Active: %SELECTED_TIER% - %IMG_WIDTH%x%IMG_HEIGHT%)
echo [5] Open Output Directory
echo [6] Exit Module
echo.
echo ============================================================================
set /p "user_choice=Select an option [1-6]: "

if "%user_choice%"=="1" goto :Generate_Image_Routine
if "%user_choice%"=="2" goto :Select_Model_Menu
if "%user_choice%"=="3" goto :Select_Aspect_Ratio_Menu
if "%user_choice%"=="4" goto :Select_Resolution_Menu
if "%user_choice%"=="5" (
    start "" "%Out_Dir%"
    goto :AI_Image_Menu
)
if "%user_choice%"=="6" exit /b 0

echo.
echo [!] Invalid selection. Please choose a valid option.
timeout /t 2 >nul
goto :AI_Image_Menu

:Select_Model_Menu
cls
echo ßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßß
echo.
echo         ßßß    ßßß   ßßßßßß   ßßßßßß   ßßßßßß   ßß   ßß  ßßßßßßß
echo         ßßßß  ßßßß  ßß    ßß  ßß   ßß  ßß   ßß  ßß   ßß  ßß     
echo         ßß ßßßß ßß  ßß    ßß  ßßßßßß   ßßßßßß   ßßßßßßß  ßßßßßßß
echo         ßß  ßß  ßß  ßß    ßß  ßß   ßß  ßß       ßß   ßß       ßß
echo         ßß      ßß   ßßßßßß   ßß   ßß  ßß       ßß   ßß  ßßßßßßß
echo.
echo  ßßßßßß  ßßßßßß  ßßßßßßß   ßßßßß  ßßßßßßßß  ßß  ßßßßßß  ßßß    ßß  ßßßßßßß
echo ßß       ßß   ßß ßß       ßß   ßß    ßß     ßß ßß    ßß ßßßß   ßß  ßß     
echo ßß       ßßßßßß  ßßßßßßß  ßßßßßßß    ßß     ßß ßß    ßß ßß ßß  ßß  ßßßßßßß
echo ßß       ßß   ßß ßß       ßß   ßß    ßß     ßß ßß    ßß ßß  ßß ßß       ßß
echo  ßßßßßß  ßß   ßß ßßßßßßß  ßß   ßß    ßß     ßß  ßßßßßß  ßß   ßßßß  ßßßßßßß
echo.
echo ßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßß
echo ============================================================================
echo                 SELECT AI MODEL ENGINE [%TOOLBOX_VER%]                     
echo ============================================================================
echo.
echo [1] Nano Banana (Google Gemini Flash Image)  [DEFAULT]
echo [2] FLUX.1 Schnell (Black Forest Labs)
echo [3] FLUX Realism (Photorealistic Fine-Tune)
echo [4] FLUX Anime (Anime & Manga Style)
echo [5] FLUX 3D (3D Digital Render Style)
echo [6] Midjourney Style Engine
echo [7] Turbo Diffusion (Ultra Fast)
echo [8] GPT Image (OpenAI Engine)
echo [9] Back to Main Menu
echo.
echo ============================================================================
set /p "model_choice=Choose model engine [1-9]: "

if "%model_choice%"=="1" (
    set "SELECTED_MODEL=nanobanana"
    set "MODEL_DISPLAY=Nano Banana (Google Gemini Flash)"
    goto :AI_Image_Menu
)
if "%model_choice%"=="2" (
    set "SELECTED_MODEL=flux"
    set "MODEL_DISPLAY=FLUX.1 Schnell"
    goto :AI_Image_Menu
)
if "%model_choice%"=="3" (
    set "SELECTED_MODEL=flux-realism"
    set "MODEL_DISPLAY=FLUX Realism"
    goto :AI_Image_Menu
)
if "%model_choice%"=="4" (
    set "SELECTED_MODEL=flux-anime"
    set "MODEL_DISPLAY=FLUX Anime Style"
    goto :AI_Image_Menu
)
if "%model_choice%"=="5" (
    set "SELECTED_MODEL=flux-3d"
    set "MODEL_DISPLAY=FLUX 3D Render"
    goto :AI_Image_Menu
)
if "%model_choice%"=="6" (
    set "SELECTED_MODEL=midjourney"
    set "MODEL_DISPLAY=Midjourney Style Engine"
    goto :AI_Image_Menu
)
if "%model_choice%"=="7" (
    set "SELECTED_MODEL=turbo"
    set "MODEL_DISPLAY=Turbo Diffusion"
    goto :AI_Image_Menu
)
if "%model_choice%"=="8" (
    set "SELECTED_MODEL=gptimage"
    set "MODEL_DISPLAY=GPT Image (OpenAI)"
    goto :AI_Image_Menu
)
if "%model_choice%"=="9" goto :AI_Image_Menu

echo.
echo [!] Invalid selection. Retrying...
timeout /t 2 >nul
goto :Select_Model_Menu

:Select_Aspect_Ratio_Menu
cls
echo ßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßß
echo.
echo         ßßß    ßßß   ßßßßßß   ßßßßßß   ßßßßßß   ßß   ßß  ßßßßßßß
echo         ßßßß  ßßßß  ßß    ßß  ßß   ßß  ßß   ßß  ßß   ßß  ßß     
echo         ßß ßßßß ßß  ßß    ßß  ßßßßßß   ßßßßßß   ßßßßßßß  ßßßßßßß
echo         ßß  ßß  ßß  ßß    ßß  ßß   ßß  ßß       ßß   ßß       ßß
echo         ßß      ßß   ßßßßßß   ßß   ßß  ßß       ßß   ßß  ßßßßßßß
echo.
echo  ßßßßßß  ßßßßßß  ßßßßßßß   ßßßßß  ßßßßßßßß  ßß  ßßßßßß  ßßß    ßß  ßßßßßßß
echo ßß       ßß   ßß ßß       ßß   ßß    ßß     ßß ßß    ßß ßßßß   ßß  ßß     
echo ßß       ßßßßßß  ßßßßßßß  ßßßßßßß    ßß     ßß ßß    ßß ßß ßß  ßß  ßßßßßßß
echo ßß       ßß   ßß ßß       ßß   ßß    ßß     ßß ßß    ßß ßß  ßß ßß       ßß
echo  ßßßßßß  ßß   ßß ßßßßßßß  ßß   ßß    ßß     ßß  ßßßßßß  ßß   ßßßß  ßßßßßßß
echo.
echo ßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßß
echo ============================================================================
echo                 SELECT ASPECT RATIO [%TOOLBOX_VER%]                        
echo ============================================================================
echo.
echo [1] 16:9  (Widescreen / Landscape / Desktop Monitor)  [DEFAULT]
echo [2] 1:1   (Square / Standard Avatar)
echo [3] 9:16  (Portrait / Mobile Phone / Story)
echo [4] 4:3   (Standard Display Monitor)
echo [5] 21:9  (Ultrawide Cinematic Widescreen)
echo [6] Back to Main Menu
echo.
echo ============================================================================
set /p "ar_choice=Choose Aspect Ratio [1-6]: "

if "%ar_choice%"=="1" set "SELECTED_AR=16:9" & goto :AI_Image_Menu
if "%ar_choice%"=="2" set "SELECTED_AR=1:1"  & goto :AI_Image_Menu
if "%ar_choice%"=="3" set "SELECTED_AR=9:16" & goto :AI_Image_Menu
if "%ar_choice%"=="4" set "SELECTED_AR=4:3"  & goto :AI_Image_Menu
if "%ar_choice%"=="5" set "SELECTED_AR=21:9" & goto :AI_Image_Menu
if "%ar_choice%"=="6" goto :AI_Image_Menu

echo.
echo [!] Invalid selection. Retrying...
timeout /t 2 >nul
goto :Select_Aspect_Ratio_Menu

:Select_Resolution_Menu
cls
echo ßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßß
echo.
echo         ßßß    ßßß   ßßßßßß   ßßßßßß   ßßßßßß   ßß   ßß  ßßßßßßß
echo         ßßßß  ßßßß  ßß    ßß  ßß   ßß  ßß   ßß  ßß   ßß  ßß     
echo         ßß ßßßß ßß  ßß    ßß  ßßßßßß   ßßßßßß   ßßßßßßß  ßßßßßßß
echo         ßß  ßß  ßß  ßß    ßß  ßß   ßß  ßß       ßß   ßß       ßß
echo         ßß      ßß   ßßßßßß   ßß   ßß  ßß       ßß   ßß  ßßßßßßß
echo.
echo  ßßßßßß  ßßßßßß  ßßßßßßß   ßßßßß  ßßßßßßßß  ßß  ßßßßßß  ßßß    ßß  ßßßßßßß
echo ßß       ßß   ßß ßß       ßß   ßß    ßß     ßß ßß    ßß ßßßß   ßß  ßß     
echo ßß       ßßßßßß  ßßßßßßß  ßßßßßßß    ßß     ßß ßß    ßß ßß ßß  ßß  ßßßßßßß
echo ßß       ßß   ßß ßß       ßß   ßß    ßß     ßß ßß    ßß ßß  ßß ßß       ßß
echo  ßßßßßß  ßß   ßß ßßßßßßß  ßß   ßß    ßß     ßß  ßßßßßß  ßß   ßßßß  ßßßßßßß
echo.
echo ßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßß
echo ============================================================================
echo                 SELECT RESOLUTION QUALITY TIER [%TOOLBOX_VER%]             
echo ============================================================================
echo.
echo [1] SD    (Standard Speed - Base ~1024 Edge)
echo [2] 1080p (Full HD Resolution)  [DEFAULT]
echo [3] 2K    (QHD High Resolution)
echo [4] 4K    (Ultra HD Resolution)
echo [5] 8K    (Extreme High Detail)
echo [6] Back to Main Menu
echo.
echo ============================================================================
set /p "tier_choice=Choose Quality Tier [1-6]: "

if "%tier_choice%"=="1" set "SELECTED_TIER=SD"    & goto :AI_Image_Menu
if "%tier_choice%"=="2" set "SELECTED_TIER=1080p" & goto :AI_Image_Menu
if "%tier_choice%"=="3" set "SELECTED_TIER=2K"    & goto :AI_Image_Menu
if "%tier_choice%"=="4" set "SELECTED_TIER=4K"    & goto :AI_Image_Menu
if "%tier_choice%"=="5" set "SELECTED_TIER=8K"    & goto :AI_Image_Menu
if "%tier_choice%"=="6" goto :AI_Image_Menu

echo.
echo [!] Invalid selection. Retrying...
timeout /t 2 >nul
goto :Select_Resolution_Menu

:Generate_Image_Routine
call :Recalculate_Dimensions
cls
echo ßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßß
echo.
echo         ßßß    ßßß   ßßßßßß   ßßßßßß   ßßßßßß   ßß   ßß  ßßßßßßß
echo         ßßßß  ßßßß  ßß    ßß  ßß   ßß  ßß   ßß  ßß   ßß  ßß     
echo         ßß ßßßß ßß  ßß    ßß  ßßßßßß   ßßßßßß   ßßßßßßß  ßßßßßßß
echo         ßß  ßß  ßß  ßß    ßß  ßß   ßß  ßß       ßß   ßß       ßß
echo         ßß      ßß   ßßßßßß   ßß   ßß  ßß       ßß   ßß  ßßßßßßß
echo.
echo  ßßßßßß  ßßßßßß  ßßßßßßß   ßßßßß  ßßßßßßßß  ßß  ßßßßßß  ßßß    ßß  ßßßßßßß
echo ßß       ßß   ßß ßß       ßß   ßß    ßß     ßß ßß    ßß ßßßß   ßß  ßß     
echo ßß       ßßßßßß  ßßßßßßß  ßßßßßßß    ßß     ßß ßß    ßß ßß ßß  ßß  ßßßßßßß
echo ßß       ßß   ßß ßß       ßß   ßß    ßß     ßß ßß    ßß ßß  ßß ßß       ßß
echo  ßßßßßß  ßß   ßß ßßßßßßß  ßß   ßß    ßß     ßß  ßßßßßß  ßß   ßßßß  ßßßßßßß
echo.
echo ßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßßß
echo ============================================================================
echo                 AI IMAGE GENERATION SUBROUTINE [%TOOLBOX_VER%]             
echo ============================================================================
echo.
echo Engine Active    : %MODEL_DISPLAY%
echo Format & Quality : %SELECTED_AR% @ %SELECTED_TIER% (%IMG_WIDTH%x%IMG_HEIGHT% Pixel Target)
echo.

set "raw_prompt="
set /p "raw_prompt=Enter prompt describing the image to generate: "

if not defined raw_prompt (
    echo.
    echo [!] Empty prompt detected.
    echo Press any key to return to menu...
    pause >nul
    goto :AI_Image_Menu
)

:: Environment Variable Handoff
set "RAW_PROMPT_VAL=!raw_prompt!"
set "MODEL_VAL=%SELECTED_MODEL%"
set "WIDTH_VAL=%IMG_WIDTH%"
set "HEIGHT_VAL=%IMG_HEIGHT%"
set "AR_VAL=%SELECTED_AR%"
set "TIER_VAL=%SELECTED_TIER%"
set "VIEWER_PATH=%T_Dir%\NativeImageViewer.exe"
set "OUT_DIR=%Out_Dir%"

echo.
echo [*] Invoking PowerShell Core Engine [%TOOLBOX_VER%]...
echo.

powershell -NoProfile -ExecutionPolicy Bypass -File "%PS_Engine%"
set "PS_EXIT_CODE=%ERRORLEVEL%"

if %PS_EXIT_CODE% neq 0 (
    echo.
    echo ============================================================================
    echo [ERROR] PowerShell engine exited with code: %PS_EXIT_CODE%
    echo [CRASH PREVENTION] Halted execution loop to retain error log above.
    echo ============================================================================
    echo.
    pause
)

goto :AI_Image_Menu


:: ============================================================================
:: SUBROUTINE: Recalculate_Dimensions
:: Matrix engine calculating exact pixel dimensions based on AR + Quality Tier
:: ============================================================================
:Recalculate_Dimensions
if "%SELECTED_AR%"=="1:1" (
    if "%SELECTED_TIER%"=="SD" ( set "IMG_WIDTH=1024" & set "IMG_HEIGHT=1024" )
    if "%SELECTED_TIER%"=="1080p" ( set "IMG_WIDTH=1080" & set "IMG_HEIGHT=1080" )
    if "%SELECTED_TIER%"=="2K" ( set "IMG_WIDTH=1440" & set "IMG_HEIGHT=1440" )
    if "%SELECTED_TIER%"=="4K" ( set "IMG_WIDTH=2160" & set "IMG_HEIGHT=2160" )
    if "%SELECTED_TIER%"=="8K" ( set "IMG_WIDTH=4320" & set "IMG_HEIGHT=4320" )
)
if "%SELECTED_AR%"=="16:9" (
    if "%SELECTED_TIER%"=="SD" ( set "IMG_WIDTH=1280" & set "IMG_HEIGHT=720" )
    if "%SELECTED_TIER%"=="1080p" ( set "IMG_WIDTH=1920" & set "IMG_HEIGHT=1080" )
    if "%SELECTED_TIER%"=="2K" ( set "IMG_WIDTH=2560" & set "IMG_HEIGHT=1440" )
    if "%SELECTED_TIER%"=="4K" ( set "IMG_WIDTH=3840" & set "IMG_HEIGHT=2160" )
    if "%SELECTED_TIER%"=="8K" ( set "IMG_WIDTH=7680" & set "IMG_HEIGHT=4320" )
)
if "%SELECTED_AR%"=="9:16" (
    if "%SELECTED_TIER%"=="SD" ( set "IMG_WIDTH=720" & set "IMG_HEIGHT=1280" )
    if "%SELECTED_TIER%"=="1080p" ( set "IMG_WIDTH=1080" & set "IMG_HEIGHT=1920" )
    if "%SELECTED_TIER%"=="2K" ( set "IMG_WIDTH=1440" & set "IMG_HEIGHT=2560" )
    if "%SELECTED_TIER%"=="4K" ( set "IMG_WIDTH=2160" & set "IMG_HEIGHT=3840" )
    if "%SELECTED_TIER%"=="8K" ( set "IMG_WIDTH=4320" & set "IMG_HEIGHT=7680" )
)
if "%SELECTED_AR%"=="4:3" (
    if "%SELECTED_TIER%"=="SD" ( set "IMG_WIDTH=1024" & set "IMG_HEIGHT=768" )
    if "%SELECTED_TIER%"=="1080p" ( set "IMG_WIDTH=1440" & set "IMG_HEIGHT=1080" )
    if "%SELECTED_TIER%"=="2K" ( set "IMG_WIDTH=1920" & set "IMG_HEIGHT=1440" )
    if "%SELECTED_TIER%"=="4K" ( set "IMG_WIDTH=2880" & set "IMG_HEIGHT=2160" )
    if "%SELECTED_TIER%"=="8K" ( set "IMG_WIDTH=5760" & set "IMG_HEIGHT=4320" )
)
if "%SELECTED_AR%"=="21:9" (
    if "%SELECTED_TIER%"=="SD" ( set "IMG_WIDTH=1344" & set "IMG_HEIGHT=576" )
    if "%SELECTED_TIER%"=="1080p" ( set "IMG_WIDTH=2560" & set "IMG_HEIGHT=1080" )
    if "%SELECTED_TIER%"=="2K" ( set "IMG_WIDTH=3440" & set "IMG_HEIGHT=1440" )
    if "%SELECTED_TIER%"=="4K" ( set "IMG_WIDTH=5120" & set "IMG_HEIGHT=2160" )
    if "%SELECTED_TIER%"=="8K" ( set "IMG_WIDTH=8064" & set "IMG_HEIGHT=3456" )
)
exit /b 0


:: ============================================================================
:: SUBROUTINE: Ensure_Engine_Script
:: Appends line-by-line to guarantee complete write without parenthesis interference
:: ============================================================================
:Ensure_Engine_Script
if exist "%PS_Engine%" del /f /q "%PS_Engine%" >nul 2>&1

setlocal DisableDelayedExpansion
echo $rawPrompt = $env:RAW_PROMPT_VAL> "%PS_Engine%"
echo $model = $env:MODEL_VAL>> "%PS_Engine%"
echo $width = $env:WIDTH_VAL>> "%PS_Engine%"
echo $height = $env:HEIGHT_VAL>> "%PS_Engine%"
echo $ar = $env:AR_VAL>> "%PS_Engine%"
echo $tier = $env:TIER_VAL>> "%PS_Engine%"
echo $viewerPath = $env:VIEWER_PATH>> "%PS_Engine%"
echo $outDir = $env:OUT_DIR>> "%PS_Engine%"
echo if ([string]::IsNullOrWhiteSpace($model)) { $model = "nanobanana" }>> "%PS_Engine%"
echo if ([string]::IsNullOrWhiteSpace($width)) { $width = "1920" }>> "%PS_Engine%"
echo if ([string]::IsNullOrWhiteSpace($height)) { $height = "1080" }>> "%PS_Engine%"
echo.>> "%PS_Engine%"
echo Write-Host "============================================================================" -ForegroundColor Green>> "%PS_Engine%"
echo Write-Host "              AI IMAGE GENERATION ENGINE (PS CORE) v0.28                    " -ForegroundColor Green>> "%PS_Engine%"
echo Write-Host "============================================================================" -ForegroundColor Green>> "%PS_Engine%"
echo Write-Host "">> "%PS_Engine%"
echo.>> "%PS_Engine%"
echo if ([string]::IsNullOrWhiteSpace($rawPrompt)) {>> "%PS_Engine%"
echo     Write-Host "[ERROR] Empty prompt received." -ForegroundColor Red>> "%PS_Engine%"
echo     Read-Host "Press Enter to return...">> "%PS_Engine%"
echo     exit 1>> "%PS_Engine%"
echo }>> "%PS_Engine%"
echo.>> "%PS_Engine%"
echo if (-not (Test-Path $viewerPath)) {>> "%PS_Engine%"
echo     Write-Host "[*] Downloading Native Image Viewer dependency..." -ForegroundColor Yellow>> "%PS_Engine%"
echo     try {>> "%PS_Engine%"
echo         [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12>> "%PS_Engine%"
echo         $wc = New-Object System.Net.WebClient>> "%PS_Engine%"
echo         $wc.Headers.Add("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0.0.0")>> "%PS_Engine%"
echo         $wc.DownloadFile("https://github.com/deminimis/minimalimageviewer/releases/download/v2.0.3/MinimalImageViewer.exe", $viewerPath)>> "%PS_Engine%"
echo         Write-Host "[OK] Native Image Viewer acquired." -ForegroundColor Green>> "%PS_Engine%"
echo     } catch {>> "%PS_Engine%"
echo         Write-Host "[ERROR] Failed to download viewer:" $_.Exception.Message -ForegroundColor Red>> "%PS_Engine%"
echo         Read-Host "Press Enter to return...">> "%PS_Engine%"
echo         exit 1>> "%PS_Engine%"
echo     }>> "%PS_Engine%"
echo }>> "%PS_Engine%"
echo.>> "%PS_Engine%"
echo $encodedPrompt = [System.Uri]::EscapeDataString($rawPrompt)>> "%PS_Engine%"
echo $seed = Get-Random -Minimum 100000 -Maximum 99999999>> "%PS_Engine%"
echo $targetFile = Join-Path $outDir "AI_Gen_$seed.jpg">> "%PS_Engine%"
echo $metaFile = Join-Path $outDir "AI_Gen_$seed.txt">> "%PS_Engine%"
echo $apiUrl = "https://image.pollinations.ai/prompt/" + $encodedPrompt + "?width=" + $width + "&height=" + $height + "&seed=" + $seed + "&model=" + $model + "&nologo=true">> "%PS_Engine%"
echo.>> "%PS_Engine%"
echo Write-Host "[*] Selected Model  : $model" -ForegroundColor Green>> "%PS_Engine%"
echo Write-Host "[*] Aspect Ratio    : $ar" -ForegroundColor Green>> "%PS_Engine%"
echo Write-Host "[*] Quality Tier    : $tier (${width}x${height})" -ForegroundColor Green>> "%PS_Engine%"
echo Write-Host "[*] Prompt Input    : $rawPrompt" -ForegroundColor Cyan>> "%PS_Engine%"
echo Write-Host "[*] Encoded Prompt  : $encodedPrompt" -ForegroundColor Cyan>> "%PS_Engine%"
echo Write-Host "[*] Request URL      : $apiUrl" -ForegroundColor Gray>> "%PS_Engine%"
echo Write-Host "[*] Requesting AI image generation (Timeout: 90s)..." -ForegroundColor Yellow>> "%PS_Engine%"
echo.>> "%PS_Engine%"
echo try {>> "%PS_Engine%"
echo     [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12>> "%PS_Engine%"
echo     $wc = New-Object System.Net.WebClient>> "%PS_Engine%"
echo     $wc.Headers.Add("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0.0.0")>> "%PS_Engine%"
echo     $wc.DownloadFile($apiUrl, $targetFile)>> "%PS_Engine%"
echo } catch {>> "%PS_Engine%"
echo     Write-Host "">> "%PS_Engine%"
echo     Write-Host "[ERROR] Generation request failed:" $_.Exception.Message -ForegroundColor Red>> "%PS_Engine%"
echo     Write-Host "">> "%PS_Engine%"
echo     Read-Host "Press Enter to return...">> "%PS_Engine%"
echo     exit 1>> "%PS_Engine%"
echo }>> "%PS_Engine%"
echo.>> "%PS_Engine%"
echo if (-not (Test-Path $targetFile)) {>> "%PS_Engine%"
echo     Write-Host "[ERROR] Target image file was not created on disk." -ForegroundColor Red>> "%PS_Engine%"
echo     Read-Host "Press Enter to return...">> "%PS_Engine%"
echo     exit 1>> "%PS_Engine%"
echo }>> "%PS_Engine%"
echo.>> "%PS_Engine%"
echo $fileSize = (Get-Item $targetFile).Length>> "%PS_Engine%"
echo if ($fileSize -lt 10240) {>> "%PS_Engine%"
echo     Write-Host "">> "%PS_Engine%"
echo     Write-Host "============================================================================" -ForegroundColor Red>> "%PS_Engine%"
echo     Write-Host "[ERROR] API returned error payload ($fileSize bytes)." -ForegroundColor Red>> "%PS_Engine%"
echo     Write-Host "==================== DIAGNOSTIC PAYLOAD CONTENTS ====================" -ForegroundColor Yellow>> "%PS_Engine%"
echo     Get-Content $targetFile>> "%PS_Engine%"
echo     Write-Host "============================================================================" -ForegroundColor Yellow>> "%PS_Engine%"
echo     Remove-Item $targetFile -Force -ErrorAction SilentlyContinue>> "%PS_Engine%"
echo     Write-Host "">> "%PS_Engine%"
echo     Read-Host "Press Enter to return...">> "%PS_Engine%"
echo     exit 1>> "%PS_Engine%"
echo }>> "%PS_Engine%"
echo.>> "%PS_Engine%"
echo # Write Sidecar Metadata Log>> "%PS_Engine%"
echo $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss">> "%PS_Engine%"
echo $logData = "============================================================================" + "`n" +>> "%PS_Engine%"
echo            "MORPHS CREATIONS AI IMAGE LOG - v0.28" + "`n" +>> "%PS_Engine%"
echo            "============================================================================" + "`n" +>> "%PS_Engine%"
echo            "Timestamp    : " + $timestamp + "`n" +>> "%PS_Engine%"
echo            "Prompt Input : " + $rawPrompt + "`n" +>> "%PS_Engine%"
echo            "Model Engine : " + $model + "`n" +>> "%PS_Engine%"
echo            "Aspect Ratio : " + $ar + "`n" +>> "%PS_Engine%"
echo            "Quality Tier : " + $tier + "`n" +>> "%PS_Engine%"
echo            "Dimensions   : " + $width + "x" + $height + "`n" +>> "%PS_Engine%"
echo            "Random Seed  : " + $seed + "`n" +>> "%PS_Engine%"
echo            "Image Target : " + $targetFile + "`n" +>> "%PS_Engine%"
echo            "API Endpoint : " + $apiUrl + "`n" +>> "%PS_Engine%"
echo            "============================================================================">> "%PS_Engine%"
echo Set-Content -Path $metaFile -Value $logData>> "%PS_Engine%"
echo.>> "%PS_Engine%"
echo Write-Host "">> "%PS_Engine%"
echo Write-Host "[SUCCESS] Image generated and validated ($fileSize bytes)." -ForegroundColor Green>> "%PS_Engine%"
echo Write-Host "[*] Saved prompt metadata to: $metaFile" -ForegroundColor Yellow>> "%PS_Engine%"
echo Write-Host "[*] Launching Native Image Viewer..." -ForegroundColor Cyan>> "%PS_Engine%"
echo ^& $viewerPath $targetFile>> "%PS_Engine%"
echo Write-Host "">> "%PS_Engine%"
echo Read-Host "Press Enter to return...">> "%PS_Engine%"
endlocal
exit /b 0